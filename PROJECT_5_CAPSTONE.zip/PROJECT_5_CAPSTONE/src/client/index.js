import  {init, readStorage} from './js/geonameApi.js'

import './styles/_index.scss';



export{
    init,readStorage
    
}
init();
