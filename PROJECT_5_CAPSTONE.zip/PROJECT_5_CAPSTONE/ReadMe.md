TRAVELING APP
The traveling app provides users with weather and geographic information of their traveling destinations
It provides these information by fetching data from 3 APIs from geoname.com, weatherbit.com and pixtabay.com
This app contains a router, server, a frontend file, along with css folders
The APIs are configure inside the router.js file for security purpose
webpack development and production files are includes to help us configure dependencies 
Jest and other dependencies were also installed 